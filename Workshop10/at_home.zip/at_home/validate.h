// OOP244 Workshop 10: Function Templates
// File: Validate.h
// Version: 1.0
// Date: 2016/04/4
// Author: ANCHETA, Jesus Jr
// ID# : 017 433 152
// Email: jjancheta@myseneca.ca

#ifndef SICT_VALIDATE_H_
#define SICT_VALIDATE_H_

namespace sict{
	template <typename T1>
	bool validate(T1 min, T1 max, T1* testValue, int x, bool* result){
		int i;
		int count = 0;
		for (i = 0; i < x; i++){
			result[i] = (testValue[i] >= min && max >= testValue[i]);
			if (result[i]){
				count++;
			}
		}
		return count == x;
	}
	template <>
	bool validate<char>(char min, char max, char* testValue, int x, bool* result){
		int i;
		int count = 0;
		for (i = 0; i < x; i++){
			result[i] = (toupper(testValue[i]) >= min && max >= toupper(testValue[i]));
			if (result[i]){
				count++;
			}
		}
		return count == x;
	}
	template <> 
	bool validate<const char>(const char* min, const char* max, const char* testValue, int x, bool* result){
		/*int i;
		int count = 0;
		for (i = 0; i < x; i++){
			result[i] = (testValue[i]) >= min && (testValue[i]) <= max);
			if (result[i]){
				count++;
			}
		}*/
		/*return count == x;*/
		return true;
	}
}
#endif